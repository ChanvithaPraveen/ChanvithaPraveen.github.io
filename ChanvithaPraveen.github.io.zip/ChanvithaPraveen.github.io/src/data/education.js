const educationData = [
    {
      institution: 'B.Sc. Eng. (Hons) in Computer Engineering',
      degree: 'Faculty of Engineering - University of Sri Jayewardenepura, Sri Lanka',
      duration: 'Minor Specialization: Data Management | GPA: 3.46/4.00 | 2019 - 2024',
      progress: 100,
      description: '',
    },
    {
      institution: 'GCE A/L Physical Science Stream',
      degree: 'Bandaranayake Central College, Veyangoda',
      duration: '2A, 1B | Z-Score: 1.713 | 2015 - 2018',
      progress: 100,
      description: 'Successfully completed the studies.',
    },
    {
      institution: 'GCE Ordinary Level Examination',
      degree: 'President\’s College, Minuwangoda',
      duration: '9A\’s | 2009 - 2014',
      progress: 100,
      description: '',
    },
  ];

  export default educationData;